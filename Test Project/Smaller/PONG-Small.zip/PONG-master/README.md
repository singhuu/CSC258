PONG
====

PONG game on Nexys3, in Verilog.

## Video Demo
* Youku: http://v.youku.com/v_show/id_XNTAwNzExNzQ4.html
* YouTube: https://www.youtube.com/watch?v=VFk-g6NZGfA
